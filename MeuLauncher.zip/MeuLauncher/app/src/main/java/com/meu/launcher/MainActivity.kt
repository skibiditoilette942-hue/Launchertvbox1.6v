package com.meu.launcher

import android.app.Activity
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/**
 * Controles:
 *  Controle remoto: setas + OK (segurar OK = menu), Voltar = fechar.
 *  Gamepad USB/BT:  D-pad / analógico esquerdo = mover, A = OK (segurar A = menu), B = voltar,
 *                   X / Start / Menu = menu do item, Y = todos os apps, Select / Guide = início.
 */
class MainActivity : Activity() {

    private class App(val pkg: String, val label: String, val icon: Drawable, val intent: Intent, val isGame: Boolean)
    private class MenuItem(val label: String, val keep: Boolean = false, val action: () -> Unit)
    private class Big(val d: Drawable, val bgColor: Int?)
    private class Layer(val view: ViewGroup, val prevFocus: View?, val onContext: (() -> Unit)?)

    companion object {
        const val SLOTS = 7
        const val ICON_PX = 192
        const val WEATHER_MS = 30 * 60 * 1000L
    }

    private val ctx: Context get() = this
    private val ui = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val net: ExecutorService = Executors.newSingleThreadExecutor() // rede separada: não atrasa os apps
    private val sh: ExecutorService = Executors.newSingleThreadExecutor()  // comandos de root
    private val decel = DecelerateInterpolator()
    private val overshoot = OvershootInterpolator(1.6f)
    private var animOn = true
    private var ambientOn = true
    private var resumed = false
    private lateinit var ambient: Ambient
    private val slotTile = arrayOfNulls<View>(SLOTS)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private var GREEN = Color.parseColor("#4CFF2A") // cor de destaque (muda em Configurações)

    // Tudo é medido em relação à altura da tela (540 = base), então fica igual em 720p, 1080p ou 4K
    private val unit: Float by lazy {
        val m = resources.displayMetrics
        minOf(m.widthPixels, m.heightPixels) / 540f
    }
    private fun dp(v: Int) = (v * unit).toInt()
    private fun TextView.px(size: Float) { setTextSize(TypedValue.COMPLEX_UNIT_PX, size * unit) }

    private var apps: List<App> = emptyList()
    private var byPkg: Map<String, App> = emptyMap()
    private var loaded = false
    private var loading = false
    private var dirty = false

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var bgView: ImageView
    private lateinit var dimView: View
    private var bgGen = 0
    private lateinit var content: LinearLayout
    private lateinit var sidebar: LinearLayout
    private lateinit var mainCol: LinearLayout
    private lateinit var featured: FrameLayout
    private lateinit var featIcon: ImageView
    private lateinit var featPlus: TextView
    private lateinit var shortcuts: LinearLayout
    private lateinit var wBox: LinearLayout
    private lateinit var statusBox: LinearLayout
    private lateinit var icNet: ImageView
    private lateinit var icPad: ImageView
    private lateinit var sysText: TextView
    private lateinit var wTemp: TextView
    private lateinit var wDesc: TextView
    private var weatherBusy = false
    private val weatherTick = Runnable { fetchWeather() }
    private var shortcutsKey = ""
    private val slotIcon = arrayOfNulls<ImageView>(SLOTS)
    private val slotPlus = arrayOfNulls<TextView>(SLOTS)
    private val layers = ArrayList<Layer>()
    private val bigCache = HashMap<String, Big>()
    private val bigPending = HashSet<String>()
    private var featBgVal = 0

    private val boxCs: Drawable.ConstantState by lazy {
        fun shape(fill: Int, stroke: Int, w: Int) = GradientDrawable().apply {
            setColor(fill); cornerRadius = dp(10).toFloat(); setStroke(dp(w), stroke)
        }
        StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(withAlpha(accentTint(1f, 0.12f), 230), GREEN, 3))
            addState(intArrayOf(), shape(Color.argb(179, 5, 10, 5), accentTint(1f, 0.42f), 1))
        }.constantState!!
    }
    private fun accentTint(sat: Float, v: Float): Int {
        val h = FloatArray(3); Color.colorToHSV(GREEN, h)
        h[1] = (h[1] * sat).coerceIn(0f, 1f); h[2] = v
        return Color.HSVToColor(h)
    }
    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun box(): Drawable = boxCs.newDrawable()

    private val reloadRunnable = Runnable { reloadApps() }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            ui.removeCallbacks(reloadRunnable); ui.postDelayed(reloadRunnable, 700)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        GREEN = prefs.getInt("accent", GREEN)
        animOn = prefs.getBoolean("anim_on", true)
        ambientOn = prefs.getBoolean("ambient_on", true)
        saverMin = prefs.getInt("saver_min", 10)

        root = FrameLayout(ctx).apply { clipChildren = false }
        bgView = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bgView, MATCH, MATCH)
        ambient = Ambient().apply { if (!ambientOn) visibility = View.GONE }
        root.addView(ambient, MATCH, MATCH)
        dimView = View(ctx).apply { setBackgroundColor(Color.BLACK); alpha = 0f }
        root.addView(dimView, MATCH, MATCH)

        sidebar = buildSidebar()
        mainCol = buildMain()
        content = LinearLayout(ctx).apply { clipChildren = false; clipToPadding = false }
        content.addView(sidebar, LinearLayout.LayoutParams(dp(76), MATCH))
        content.addView(mainCol, LinearLayout.LayoutParams(0, MATCH, 1f))
        root.addView(content, MATCH, MATCH)
        buildSaver()
        setContentView(root)

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(pkgReceiver, f)

        reloadApps()      // em segundo plano: a tela abre na hora
        applyBackground() // em segundo plano
        intro()
        startWeather()
        if (prefs.getBoolean("perf_on", false)) setPerf(true, quiet = true) // reaplica o modo desempenho ao ligar a box
        checkAutostart()
    }

    override fun onResume() {
        super.onResume()
        resumed = true; updateAmbient()
        applyStatusVisibility(); resetIdle(true)
        if (content.alpha < 1f || content.scaleX != 1f) fx(content, 280, scale = 1f, alpha = 1f)
        if (System.currentTimeMillis() - prefs.getLong("w_time", 0L) > WEATHER_MS) fetchWeather()
        if (layers.isEmpty() && currentFocus == null) featured.requestFocus()
    }

    override fun onPause() {
        resumed = false
        ui.removeCallbacks(statusTick); ui.removeCallbacks(idleRun)
        if (saverOn) hideSaver()
        saveElapsed()
        updateAmbient()
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        goHome()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        if (::ambient.isInitialized) ambient.stop()
        io.shutdownNow()
        net.shutdownNow()
        sh.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (layers.isNotEmpty()) popLayer() // launcher nunca fecha com Voltar
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    // ---------------------------------------------------------------- controle remoto / gamepad
    // O Android já converte D-pad e analógico esquerdo de qualquer gamepad em setas.
    // Aqui só mapeamos os botões que ele não trata.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (saverOn) { if (e.action == KeyEvent.ACTION_DOWN) hideSaver(); return true } // 1º toque só acorda a tela
        userActivity()
        val down = e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0
        when (e.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A ->
                return super.dispatchKeyEvent(KeyEvent(e.downTime, e.eventTime, e.action, KeyEvent.KEYCODE_DPAD_CENTER, e.repeatCount))
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_ESCAPE -> { if (down) onBackPressed(); return true }
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_MENU -> { if (down) contextAction(); return true }
            KeyEvent.KEYCODE_BUTTON_Y -> { if (down) { closeAllLayers(); showApps(false) }; return true }
            KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_MODE -> { if (down) goHome(); return true }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT ->
                if (e.action == KeyEvent.ACTION_DOWN && currentFocus == null) { focusDefault(); return true }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun contextAction() {
        val l = layers.lastOrNull()
        if (l != null) l.onContext?.invoke() else currentFocus?.performLongClick()
    }

    private fun focusDefault() {
        if (layers.isNotEmpty()) topGroup().requestFocus() else featured.requestFocus()
    }

    private fun goHome() {
        closeAllLayers()
        if (this::featured.isInitialized) featured.requestFocus()
    }

    // ---------------------------------------------------------------- camadas (lista de apps / menus)
    private fun topGroup(): ViewGroup = layers.lastOrNull()?.view ?: content

    private fun pushLayer(v: ViewGroup, target: View, onContext: (() -> Unit)?) {
        val prev = currentFocus
        topGroup().descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS // foco não vaza pra tela de trás
        root.addView(v, MATCH, MATCH)
        layers.add(Layer(v, prev, onContext))
        v.alpha = 0f; v.scaleX = 0.95f; v.scaleY = 0.95f
        fx(v, 200, scale = 1f, alpha = 1f)
        updateAmbient()
        target.requestFocus()
    }

    private fun popLayer() {
        val l = layers.removeLastOrNull() ?: return
        fxStop(l.view)
        root.removeView(l.view)
        topGroup().descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
        val p = l.prevFocus
        if (p != null && p.isAttachedToWindow && p.visibility == View.VISIBLE) p.requestFocus()
        else focusDefault()
        updateAmbient()
    }

    private fun closeAllLayers() { while (layers.isNotEmpty()) popLayer() }

    // ---------------------------------------------------------------- dados (em segundo plano)
    private fun reloadApps() {
        if (loading) { dirty = true; return }
        loading = true
        io.execute {
            val list = try { queryApps() } catch (t: Throwable) { emptyList() }
            ui.post {
                loading = false
                if (isDestroyed) return@post
                apps = list; byPkg = list.associateBy { it.pkg }; loaded = true
                refreshUi()
                if (dirty) { dirty = false; reloadApps() }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun queryApps(): List<App> {
        val pm = packageManager
        val map = HashMap<String, App>()
        for (cat in arrayOf(Intent.CATEGORY_LAUNCHER, Intent.CATEGORY_LEANBACK_LAUNCHER)) {
            for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || map.containsKey(p)) continue
                val ai = ri.activityInfo.applicationInfo
                val game = (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) ||
                        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                val launch = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(p, ri.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val icon = try { toBitmapIcon(ri.loadIcon(pm)) } catch (t: Throwable) { toBitmapIcon(pm.defaultActivityIcon) }
                map[p] = App(p, ri.loadLabel(pm).toString(), icon, launch, game)
            }
        }
        return map.values.sortedBy { it.label.lowercase() }
    }

    // Converte o ícone em bitmap pequeno: desenha mais rápido e gasta menos memória
    private fun toBitmapIcon(d: Drawable): Drawable {
        val bmp = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, ICON_PX, ICON_PX)
        d.draw(Canvas(bmp))
        return BitmapDrawable(resources, bmp)
    }

    // ---------------------------------------------------------------- plano de fundo
    private fun decodeScaled(maxW: Int = 0, decode: (BitmapFactory.Options) -> Bitmap?): Bitmap? {
        val m = resources.displayMetrics
        val target = if (maxW > 0) maxW else maxOf(m.widthPixels, m.heightPixels)
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        decode(o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= target) sample *= 2
        return decode(BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun setBgGradient(name: String) {
        val c = when (name) {
            "azul" -> "#0B2A5C"
            "roxo" -> "#3A0F5C"
            "vermelho" -> "#5C0F0F"
            "preto" -> "#0A0A0A"
            else -> "#0B4A0B"
        }
        fxStop(bgView); bgView.alpha = 1f
        bgView.setImageDrawable(null)
        bgView.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.BLACK, Color.parseColor(c)))
    }

    private fun applyBackground() {
        val gen = ++bgGen
        dimView.alpha = prefs.getInt("bg_dim", 0) / 100f
        val mode = prefs.getString("bg_mode", "default") ?: "default"
        if (mode.startsWith("preset:")) { setBgGradient(mode.substring(7)); return }
        val resId = resources.getIdentifier("background", "drawable", packageName)
        val fileMode = mode == "custom" || mode == "folder"
        if (!fileMode && resId == 0) { setBgGradient("verde"); return }
        io.execute {
            val bmp = try {
                when (mode) {
                    "custom" -> {
                        val p = File(filesDir, "bg_custom.jpg").path
                        decodeScaled { BitmapFactory.decodeFile(p, it) }
                    }
                    "folder" -> {
                        val dir = getExternalFilesDir(null)
                        val f = if (dir == null) null else
                            listOf("background.jpg", "background.png", "background.jpeg").map { File(dir, it) }.firstOrNull { it.exists() }
                        val p = f?.path ?: ""
                        decodeScaled { BitmapFactory.decodeFile(p, it) }
                    }
                    else -> decodeScaled { BitmapFactory.decodeResource(resources, resId, it) }
                }
            } catch (t: Throwable) { null }
            ui.post {
                if (isDestroyed || gen != bgGen) return@post
                if (bmp != null) {
                    bgView.background = null; bgView.setImageBitmap(bmp); bgView.alpha = 0f
                    fx(bgView, 350, alpha = 1f)
                } else {
                    if (fileMode) Toast.makeText(ctx, "Imagem não encontrada", Toast.LENGTH_LONG).show()
                    setBgGradient("verde")
                }
            }
        }
    }

    private fun pickBgImage() {
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 42)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Nenhum app de arquivos encontrado. Use a opção Imagem da pasta do launcher.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == 43) {
            val pkg = prefs.getString("banner_pending", null) ?: return
            storeBanner(pkg) { decodeScaled(1280) { o -> contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } } }
            return
        }
        if (requestCode != 42) return
        io.execute {
            val bmp = try {
                decodeScaled { o -> contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } }
            } catch (t: Throwable) { null }
            var ok = false
            if (bmp != null) try {
                FileOutputStream(File(filesDir, "bg_custom.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                ok = true
            } catch (t: Throwable) {}
            ui.post {
                if (isDestroyed) return@post
                if (ok) { prefs.edit().putString("bg_mode", "custom").apply(); applyBackground() }
                else Toast.makeText(ctx, "Não foi possível usar essa imagem", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------------------------------------------------------------- menu de configurações do launcher
    private fun showSettingsMenu() {
        showMenu("Configurações do launcher", listOf(
            MenuItem("Otimizador  ›", keep = true) { showOptimizerMenu() },
            MenuItem("Aparência  ›", keep = true) { showAppearanceMenu() },
            MenuItem("Tela inicial  ›", keep = true) { showHomeMenu() },
            MenuItem("Escolher launcher padrão") {
                try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                catch (e: Exception) { Toast.makeText(ctx, "Não disponível neste aparelho", Toast.LENGTH_SHORT).show() }
            },
            MenuItem("Restaurar visual padrão") {
                prefs.edit().remove("bg_mode").remove("bg_dim").remove("accent").remove("weather_on")
                    .remove("anim_on").remove("ambient_on").remove("status_on").remove("saver_min").apply()
                recreate()
            },
            MenuItem("Configurações do Android") {
                try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
            }
        ))
    }

    private fun showAppearanceMenu() {
        showMenu("Aparência", listOf(
            MenuItem("Plano de fundo  ›", keep = true) { showBgMenu() },
            MenuItem("Escurecer fundo  ›", keep = true) { showDimMenu() },
            MenuItem("Cor de destaque  ›", keep = true) { showAccentMenu() },
            MenuItem(if (animOn) "Animações: ligadas" else "Animações: desligadas", keep = true) {
                animOn = !animOn; prefs.edit().putBoolean("anim_on", animOn).apply()
                popLayer(); showAppearanceMenu()
            },
            MenuItem(if (ambientOn) "Fundo animado: ligado" else "Fundo animado: desligado", keep = true) {
                ambientOn = !ambientOn; prefs.edit().putBoolean("ambient_on", ambientOn).apply()
                popLayer(); showAppearanceMenu()
            }
        ))
    }

    private fun showHomeMenu() {
        val weatherOn = prefs.getBoolean("weather_on", true)
        val statusOn = prefs.getBoolean("status_on", true)
        val auto = appFor("autostart")
        showMenu("Tela inicial", listOf(
            MenuItem(if (statusOn) "Barra de status: ligada" else "Barra de status: desligada", keep = true) {
                prefs.edit().putBoolean("status_on", !statusOn).apply()
                applyStatusVisibility(); popLayer(); showHomeMenu()
            },
            MenuItem(if (weatherOn) "Clima: ligado" else "Clima: desligado", keep = true) {
                prefs.edit().putBoolean("weather_on", !weatherOn).apply()
                startWeather(); popLayer(); showHomeMenu()
            },
            MenuItem("Abrir ao ligar: " + (auto?.label ?: "nenhum") + "  ›", keep = true) { showAutostartMenu() },
            MenuItem("Protetor de tela: " + (if (saverMin == 0) "desligado" else "$saverMin min") + "  ›", keep = true) { showSaverMenu() },
            MenuItem("Apps escondidos  ›") { showHiddenApps() }
        ))
    }

    private fun showAutostartMenu() {
        showMenu("Abrir ao ligar a box", listOf(
            MenuItem("Escolher app") { pickFor("autostart") },
            MenuItem("Nenhum (desativar)") {
                prefs.edit().putString("autostart", "").apply()
                Toast.makeText(ctx, "Desativado", Toast.LENGTH_SHORT).show()
            }
        ))
    }

    private fun showSaverMenu() {
        showMenu("Protetor de tela", listOf(0 to "Desligado", 2 to "Após 2 minutos", 5 to "Após 5 minutos",
            10 to "Após 10 minutos", 30 to "Após 30 minutos").map { (m, n) ->
            MenuItem(n, keep = true) {
                saverMin = m; prefs.edit().putInt("saver_min", m).apply(); resetIdle(true)
                popLayer(); popLayer(); showHomeMenu()
            }
        })
    }

    private fun hiddenSet(): Set<String> = gameSet("hidden_apps")

    private fun visibleApps(gamesOnly: Boolean): List<App> {
        val hs = hiddenSet()
        return apps.filter { !hs.contains(it.pkg) && (!gamesOnly || isGameApp(it)) }
    }

    private fun hideApp(a: App, hide: Boolean) {
        val set = gameSet("hidden_apps").toMutableSet()
        if (hide) set.add(a.pkg) else set.remove(a.pkg)
        prefs.edit().putStringSet("hidden_apps", set).apply()
    }

    private fun showHiddenApps() {
        val hs = hiddenSet()
        val list = apps.filter { hs.contains(it.pkg) }
        if (list.isEmpty()) { Toast.makeText(ctx, "Nenhum app escondido", Toast.LENGTH_SHORT).show(); return }
        showPicker("Apps escondidos: toque para mostrar de novo", list, { a ->
            hideApp(a, false); popLayer()
            Toast.makeText(ctx, a.label + " voltou para a lista", Toast.LENGTH_SHORT).show()
        }, null)
    }

    private fun showBgMenu() {
        fun set(mode: String) { prefs.edit().putString("bg_mode", mode).apply(); applyBackground() }
        showMenu("Plano de fundo", listOf(
            MenuItem("Escolher imagem do aparelho") { pickBgImage() },
            MenuItem("Imagem da pasta do launcher") {
                val dir = getExternalFilesDir(null)
                val has = dir != null && listOf("background.jpg", "background.png", "background.jpeg").any { File(dir, it).exists() }
                if (has) set("folder")
                else Toast.makeText(ctx, "Coloque background.jpg em ${dir?.absolutePath}", Toast.LENGTH_LONG).show()
            },
            MenuItem("Verde") { set("preset:verde") },
            MenuItem("Azul") { set("preset:azul") },
            MenuItem("Roxo") { set("preset:roxo") },
            MenuItem("Vermelho") { set("preset:vermelho") },
            MenuItem("Preto") { set("preset:preto") },
            MenuItem("Padrão do launcher") { set("default") }
        ))
    }

    private fun showDimMenu() {
        showMenu("Escurecer fundo", listOf(0 to "Nenhum", 30 to "30%", 50 to "50%", 70 to "70%").map { (v, n) ->
            MenuItem(n) { prefs.edit().putInt("bg_dim", v).apply(); dimView.alpha = v / 100f }
        })
    }

    private fun showAccentMenu() {
        val opts = listOf("Verde" to "#4CFF2A", "Azul" to "#2AA8FF", "Ciano" to "#2AF0E0", "Roxo" to "#B04CFF",
            "Laranja" to "#FF9A2A", "Vermelho" to "#FF3B3B", "Rosa" to "#FF4CB0", "Amarelo" to "#FFE62A")
        showMenu("Cor de destaque", opts.map { (n, c) ->
            MenuItem(n) { prefs.edit().putInt("accent", Color.parseColor(c)).apply(); recreate() }
        })
    }

    private fun pkgFor(key: String): String? {
        val s = prefs.getString(key, null)
        if (s == null && key == "featured")
            return listOf("com.google.android.youtube", "com.google.android.youtube.tv").firstOrNull { byPkg.containsKey(it) }
        return s?.takeIf { it.isNotEmpty() }
    }
    private fun appFor(key: String): App? = pkgFor(key)?.let { byPkg[it] }

    private fun launch(a: App) {
        try {
            startActivity(a.intent)
            fx(content, 240, interp = AccelerateInterpolator(), scale = 1.1f, alpha = 0f)
            // segurança: se o app não abriu e o launcher continua na tela, a tela volta
            ui.postDelayed({ if (resumed && !isFinishing) fx(content, 250, scale = 1f, alpha = 1f) }, 1800)
        } catch (e: Exception) { Toast.makeText(ctx, "Não foi possível abrir", Toast.LENGTH_SHORT).show() }
    }

    // ---------------------------------------------------------------- visual
    // ---------------------------------------------------------------- motor de animação próprio
    // Roda por conta própria (Choreographer). Assim funciona mesmo se a box estiver com a
    // "escala de animação" desligada nas opções do desenvolvedor, o que é comum em TV box.
    private val choreo: Choreographer by lazy { Choreographer.getInstance() }
    private val active = HashMap<View, ArrayList<Tween>>()

    private inner class Tween(
        val v: View, val ms: Long, val delay: Long, val interp: Interpolator,
        var scale: Float?, var alpha: Float?, var tx: Float?, var ty: Float?
    ) : Choreographer.FrameCallback {
        private var t0 = 0L
        var dead = false
        private val s0 = v.scaleX
        private val a0 = v.alpha
        private val x0 = v.translationX
        private val y0 = v.translationY
        fun idle() = scale == null && alpha == null && tx == null && ty == null
        override fun doFrame(frameTimeNanos: Long) {
            if (dead) return
            val now = frameTimeNanos / 1_000_000L
            if (t0 == 0L) t0 = now
            val el = now - t0 - delay
            if (el < 0) { choreo.postFrameCallback(this); return }
            val f = if (ms <= 0L) 1f else (el.toFloat() / ms).coerceIn(0f, 1f)
            val e = interp.getInterpolation(f)
            scale?.let { val sv = s0 + (it - s0) * e; v.scaleX = sv; v.scaleY = sv }
            alpha?.let { v.alpha = a0 + (it - a0) * e }
            tx?.let { v.translationX = x0 + (it - x0) * e }
            ty?.let { v.translationY = y0 + (it - y0) * e }
            if (f < 1f) choreo.postFrameCallback(this)
            else { dead = true; active[v]?.let { l -> l.remove(this); if (l.isEmpty()) active.remove(v) } }
        }
    }

    private fun fx(v: View, ms: Long, delay: Long = 0L, interp: Interpolator = decel,
                   scale: Float? = null, alpha: Float? = null, tx: Float? = null, ty: Float? = null) {
        if (!animOn) { // animações desligadas: vai direto ao valor final
            fxStop(v)
            scale?.let { v.scaleX = it; v.scaleY = it }
            alpha?.let { v.alpha = it }
            tx?.let { v.translationX = it }
            ty?.let { v.translationY = it }
            return
        }
        val list = active.getOrPut(v) { ArrayList() }
        for (o in list) {
            if (scale != null) o.scale = null
            if (alpha != null) o.alpha = null
            if (tx != null) o.tx = null
            if (ty != null) o.ty = null
            if (o.idle()) o.dead = true
        }
        list.removeAll { it.dead }
        val t = Tween(v, ms, delay, interp, scale, alpha, tx, ty)
        list.add(t)
        choreo.postFrameCallback(t)
    }

    private fun fxStop(v: View) { active.remove(v)?.forEach { it.dead = true } }

    private fun focusAnim(v: View, scale: Float) {
        v.onFocusChangeListener = View.OnFocusChangeListener { view, has ->
            if (has) fx(view, 220, interp = overshoot, scale = scale) else fx(view, 140, scale = 1f)
        }
    }

    // Entrada em cascata: barra lateral desliza, card e espaços sobem um por um
    private fun intro() {
        for (i in 0 until sidebar.childCount) {
            val c = sidebar.getChildAt(i)
            c.alpha = 0f; c.translationX = -dp(36).toFloat()
            fx(c, 380, delay = 60L * i, tx = 0f, alpha = 1f)
        }
        featured.alpha = 0f; featured.translationY = dp(30).toFloat()
        fx(featured, 420, delay = 120, ty = 0f, alpha = 1f)
        for (i in 0 until SLOTS) {
            val t = slotTile[i] ?: continue
            t.alpha = 0f; t.translationY = dp(36).toFloat()
            fx(t, 380, delay = 260L + i * 70L, ty = 0f, alpha = 1f)
        }
    }

    // Luzes suaves que passeiam pelo fundo. Pausa sozinho com menu aberto ou fora da tela
    // e se desliga sozinho se a box não aguentar.
    private inner class Ambient : View(ctx) {
        private val paints = Array(3) { Paint(Paint.ANTI_ALIAS_FLAG) }
        private var t = 0f
        private var running = false
        private var last = 0L
        private var gapSum = 0L
        private var gapN = 0
        private var bad = 0
        private val cb = object : Choreographer.FrameCallback {
            override fun doFrame(n: Long) {
                if (!running) return
                val ms = n / 1_000_000L
                if (last == 0L) last = ms
                val gap = ms - last
                if (gap >= 32) { // ~30 quadros por segundo
                    last = ms
                    t += gap / 1000f
                    gapSum += gap; gapN++
                    if (gapN >= 60) {
                        if (gapSum / gapN > 60) bad++ else bad = 0
                        gapSum = 0; gapN = 0
                        if (bad >= 2) { running = false; ambientTooSlow(); return }
                    }
                    invalidate()
                }
                choreo.postFrameCallback(this)
            }
        }
        fun start() { if (!running) { running = true; last = 0L; gapSum = 0; gapN = 0; choreo.postFrameCallback(cb) } }
        fun stop() { running = false; choreo.removeFrameCallback(cb) }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            val r = h * 0.6f
            val cols = intArrayOf(
                withAlpha(accentTint(0.9f, 1f), 60), withAlpha(accentTint(0.7f, 0.8f), 45), withAlpha(accentTint(1f, 0.6f), 55))
            for (k in 0..2) paints[k].shader = RadialGradient(0f, 0f, r, cols[k], withAlpha(cols[k], 0), Shader.TileMode.CLAMP)
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val r = h * 0.6f
            for (k in 0..2) {
                val cx = w * (0.5f + 0.42f * Math.sin((t * (0.11f + 0.04f * k) + k * 2.1f).toDouble()).toFloat())
                val cy = h * (0.5f + 0.40f * Math.cos((t * (0.15f + 0.03f * k) + k * 1.7f).toDouble()).toFloat())
                c.save(); c.translate(cx, cy); c.drawCircle(0f, 0f, r, paints[k]); c.restore()
            }
        }
    }

    private fun ambientTooSlow() {
        ambientOn = false
        prefs.edit().putBoolean("ambient_on", false).apply()
        ambient.visibility = View.GONE
        Toast.makeText(ctx, "Fundo animado desligado: a box está lenta. Dá para religar em Configurações.", Toast.LENGTH_LONG).show()
    }

    private fun updateAmbient() {
        if (!::ambient.isInitialized) return
        if (ambientOn && resumed && layers.isEmpty() && !saverOn) { ambient.visibility = View.VISIBLE; ambient.start() }
        else ambient.stop()
        if (!ambientOn) ambient.visibility = View.GONE
    }

    private fun sq(size: Int) = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(0, dp(6), 0, dp(6)) }

    private fun sideBtn(res: Int, action: () -> Unit): ImageView = ImageView(ctx).apply {
        setImageResource(res); setColorFilter(accentTint(0.2f, 1f))
        setPadding(dp(12), dp(12), dp(12), dp(12)); isFocusable = true; background = box()
        setOnClickListener { action() }
        focusAnim(this, 1.18f)
    }

    private fun buildSidebar(): LinearLayout {
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            clipChildren = false; clipToPadding = false
            setPadding(0, dp(16), 0, dp(8)); setBackgroundColor(Color.parseColor("#B3000000"))
        }
        bar.addView(sideBtn(R.drawable.ic_home) { goHome() }, sq(52))
        bar.addView(sideBtn(R.drawable.ic_games) { showApps(true) }, sq(52))
        bar.addView(sideBtn(R.drawable.ic_apps) { showApps(false) }, sq(52))
        bar.addView(sideBtn(R.drawable.ic_settings) { showSettingsMenu() }, sq(52))
        bar.addView(View(ctx).apply { setBackgroundColor(accentTint(1f, 0.55f)) },
            LinearLayout.LayoutParams(dp(36), 1.coerceAtLeast(dp(1))).apply { setMargins(0, dp(10), 0, dp(10)) })
        shortcuts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false }
        bar.addView(shortcuts, LinearLayout.LayoutParams(MATCH, WRAP))
        bar.addView(View(ctx), LinearLayout.LayoutParams(1, 0, 1f))
        bar.addView(sideBtn(R.drawable.ic_power) { showPowerMenu() }, sq(52))
        return bar
    }

    private fun tile(isFeatured: Boolean, plusSize: Float, key: String, scale: Float): Triple<FrameLayout, ImageView, TextView> {
        val t = FrameLayout(ctx).apply { isFocusable = true; background = box() }
        val ic = ImageView(ctx).apply { visibility = View.GONE }
        run {
            ic.scaleType = ImageView.ScaleType.CENTER_CROP
            ic.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(8).toFloat()) }
            }
            ic.clipToOutline = true
            t.addView(ic, FrameLayout.LayoutParams(MATCH, MATCH).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        val pl = TextView(ctx).apply {
            text = "+"; px(plusSize); gravity = Gravity.CENTER; setTextColor(Color.parseColor("#8AA88A")); visibility = View.GONE
        }
        t.addView(pl, FrameLayout.LayoutParams(MATCH, MATCH))
        focusAnim(t, scale)
        t.setOnClickListener {
            if (!loaded) return@setOnClickListener
            val a = appFor(key)
            if (a == null) pickFor(key) else launch(a)
        }
        t.setOnLongClickListener {
            if (loaded) { if (appFor(key) != null) tileMenu(key) else pickFor(key) }
            true
        }
        return Triple(t, ic, pl)
    }

    private fun buildMain(): LinearLayout {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false
            setPadding(dp(24), dp(8), dp(32), dp(24))
        }
        val top = LinearLayout(ctx).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val clk = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        clk.addView(TextClock(ctx).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"; px(32f)
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(accentTint(0.45f, 1f))
        })
        clk.addView(TextClock(ctx).apply {
            format12Hour = "EEE, dd MMM yyyy"; format24Hour = "EEE, dd MMM yyyy"; px(13f)
            setTextColor(Color.parseColor("#D0E8D0"))
        })
        wBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.END; visibility = View.GONE
            setPadding(dp(20), 0, 0, 0)
        }
        wTemp = TextView(ctx).apply { px(24f); setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(accentTint(0.45f, 1f)) }
        wDesc = TextView(ctx).apply { px(13f); setTextColor(Color.parseColor("#D0E8D0")) }
        wBox.addView(wTemp); wBox.addView(wDesc)
        statusBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, dp(22), 0)
            visibility = if (prefs.getBoolean("status_on", true)) View.VISIBLE else View.GONE
        }
        icNet = ImageView(ctx).apply { setImageResource(R.drawable.ic_wifi); setColorFilter(accentTint(0.5f, 1f)); alpha = 0.3f }
        icPad = ImageView(ctx).apply { setImageResource(R.drawable.ic_games); setColorFilter(accentTint(0.5f, 1f)); visibility = View.GONE }
        sysText = TextView(ctx).apply { px(12f); setTextColor(accentTint(0.2f, 1f)); gravity = Gravity.END }
        statusBox.addView(icNet, LinearLayout.LayoutParams(dp(22), dp(22)).apply { setMargins(0, 0, dp(8), 0) })
        statusBox.addView(icPad, LinearLayout.LayoutParams(dp(22), dp(22)).apply { setMargins(0, 0, dp(10), 0) })
        statusBox.addView(sysText)
        top.addView(statusBox)
        top.addView(clk)
        top.addView(wBox)
        col.addView(top, LinearLayout.LayoutParams(MATCH, dp(64)))

        val f = tile(true, 60f, "featured", 1.05f)
        featured = f.first; featIcon = f.second; featPlus = f.third
        col.addView(featured, LinearLayout.LayoutParams(dp(520), 0, 1f).apply { bottomMargin = dp(16) })

        val row = LinearLayout(ctx).apply { clipChildren = false; clipToPadding = false }
        for (i in 0 until SLOTS) {
            val s = tile(false, 34f, "slot$i", 1.1f)
            slotIcon[i] = s.second; slotPlus[i] = s.third; slotTile[i] = s.first
            row.addView(s.first, LinearLayout.LayoutParams(0, MATCH, 1f).apply { setMargins(dp(7), 0, dp(7), 0) })
        }
        col.addView(row, LinearLayout.LayoutParams(MATCH, dp(96)))
        return col
    }

    private fun showTile(icon: ImageView, plus: TextView, a: App?, d: Drawable? = a?.icon) {
        if (!loaded) { icon.visibility = View.GONE; plus.visibility = View.GONE; return }
        if (a == null) { icon.tag = null; icon.visibility = View.GONE; plus.visibility = View.VISIBLE; return }
        plus.visibility = View.GONE
        icon.setImageDrawable(d)
        icon.visibility = View.VISIBLE
        if (icon.tag != a.pkg) { // só anima quando o app muda
            icon.tag = a.pkg
            icon.scaleX = 0.6f; icon.scaleY = 0.6f; icon.alpha = 0f
            fx(icon, 300, interp = overshoot, scale = 1f, alpha = 1f)
        }
    }

    private fun refreshUi() {
        for (i in 0 until SLOTS) showTile(slotIcon[i]!!, slotPlus[i]!!, appFor("slot$i"))
        showFeatured()
        val list = listOf("com.google.android.googlequicksearchbox", "com.android.vending").mapNotNull { byPkg[it] }
        val k = list.joinToString(",") { it.pkg }
        if (k != shortcutsKey) {
            shortcutsKey = k
            shortcuts.removeAllViews()
            for (a in list) shortcuts.addView(ImageView(ctx).apply {
                setImageDrawable(a.icon); setPadding(dp(10), dp(10), dp(10), dp(10))
                isFocusable = true; background = box(); setOnClickListener { launch(a) }
                focusAnim(this, 1.18f)
            }, sq(52))
        }
        if (layers.isEmpty() && currentFocus == null) featured.requestFocus()
    }

    // ---------------------------------------------------------------- card grande (ícone em alta, sem o fundo "quadrado")
    private fun cdist(a: Int, b: Int) =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) + Math.abs(Color.blue(a) - Color.blue(b))

    private fun coloredBox(c: Int): Drawable {
        fun shape(stroke: Int, w: Int) = GradientDrawable().apply {
            setColor(c); cornerRadius = dp(10).toFloat(); setStroke(dp(w), stroke)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(GREEN, 3))
            addState(intArrayOf(), shape(accentTint(1f, 0.42f), 1))
        }
    }

    private fun showFeatured() {
        val a = appFor("featured")
        val b = a?.let { bigCache[it.pkg] }
        if (a != null && b == null) {
            if (loaded) { featIcon.visibility = View.GONE; featPlus.visibility = View.GONE }
            requestBig(a); return
        }
        showTile(featIcon, featPlus, a, b?.d)
        val bg = b?.bgColor ?: 0
        if (bg != featBgVal) {
            featBgVal = bg
            featured.background = if (bg != 0) coloredBox(bg) else box()
        }
    }

    private fun requestBig(a: App) {
        if (!bigPending.add(a.pkg)) return
        io.execute {
            val b = try { buildCard(a) } catch (t: Throwable) { Big(a.icon, null) }
            ui.post {
                bigPending.remove(a.pkg)
                if (!isDestroyed) { bigCache[a.pkg] = b; showFeatured() }
            }
        }
    }

    private class Logo(val bmp: Bitmap, val dom: Int, val clean: Boolean)

    // Cor mais marcante do ícone (ex.: vermelho do YouTube)
    private fun domColor(px: IntArray): Int {
        var r = 0L; var g = 0L; var b = 0L; var n = 0
        val hsv = FloatArray(3)
        var k = 0
        while (k < px.size) {
            val p = px[k]
            if (Color.alpha(p) > 200) {
                Color.colorToHSV(p, hsv)
                if (hsv[1] > 0.45f && hsv[2] > 0.35f) { r += Color.red(p); g += Color.green(p); b += Color.blue(p); n++ }
            }
            k += 7
        }
        return if (n < 20) GREEN else Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
    }

    // Desenha o ícone em alta, tira o fundo uniforme (ex.: o quadrado branco do YouTube) e recorta no logo
    private fun bigLogo(a: App): Logo {
        val s = 512
        val d = packageManager.getActivityIcon(a.intent.component!!)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s); d.draw(Canvas(bmp))
        val px = IntArray(s * s); bmp.getPixels(px, 0, s, 0, 0, s, s)
        val plain = Logo(bmp, domColor(px), false)
        val i = s / 10
        val samples = intArrayOf(px[i * s + s / 2], px[(s - 1 - i) * s + s / 2], px[(s / 2) * s + i], px[(s / 2) * s + s - 1 - i])
        val c = samples[0]
        if (Color.alpha(c) < 200 || samples.any { cdist(it, c) > 40 }) return plain
        val light = minOf(Color.red(c), Color.green(c), Color.blue(c)) > 215
        fun isBg(p: Int): Boolean {
            if (Color.alpha(p) < 30) return true
            if (!light) return cdist(p, c) <= 60
            val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
            return maxOf(r, g, b) - minOf(r, g, b) <= 30 && minOf(r, g, b) > 140
        }
        val bg = BooleanArray(s * s)
        val stack = IntArray(s * s)
        var sp = 0
        fun push(x: Int, y: Int) { val k = y * s + x; if (!bg[k] && isBg(px[k])) { bg[k] = true; stack[sp++] = k } }
        for (t in 0 until s) { push(t, 0); push(t, s - 1); push(0, t); push(s - 1, t) }
        push(s / 2, i); push(s / 2, s - 1 - i); push(i, s / 2); push(s - 1 - i, s / 2)
        while (sp > 0) {
            val k = stack[--sp]; val x = k % s; val y = k / s
            if (x > 0) push(x - 1, y)
            if (x < s - 1) push(x + 1, y)
            if (y > 0) push(x, y - 1)
            if (y < s - 1) push(x, y + 1)
        }
        // engorda o fundo em 3 pixels: tira o contorno claro que sobra em volta do logo
        repeat(3) {
            val nb = bg.copyOf()
            for (y in 1 until s - 1) for (x in 1 until s - 1) {
                val k = y * s + x
                if (!bg[k] && (bg[k - 1] || bg[k + 1] || bg[k - s] || bg[k + s])) nb[k] = true
            }
            System.arraycopy(nb, 0, bg, 0, nb.size)
        }
        var minX = s; var minY = s; var maxX = -1; var maxY = -1; var removed = 0
        for (k in px.indices) {
            if (bg[k]) { px[k] = 0; removed++ }
            else {
                val x = k % s; val y = k / s
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (maxX < 0 || removed > px.size * 0.92) return plain
        // borda meio transparente: suaviza o serrilhado
        for (y in 1 until s - 1) for (x in 1 until s - 1) {
            val k = y * s + x
            if (!bg[k] && (bg[k - 1] || bg[k + 1] || bg[k - s] || bg[k + s])) px[k] = (px[k] and 0x00FFFFFF) or (0x80 shl 24)
        }
        val dom = domColor(px)
        bmp.setPixels(px, 0, s, 0, 0, s, s)
        return Logo(Bitmap.createBitmap(bmp, minX, minY, maxX - minX + 1, maxY - minY + 1), dom, true)
    }

    // Banner no estilo "arte de capa": fundo escuro, faixas diagonais na cor do app e o logo no meio
    private fun makeBanner(lg: Logo): Big {
        val w = dp(520); val h = dp(330)
        val wf = w.toFloat(); val hf = h.toFloat()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val hsv = FloatArray(3); Color.colorToHSV(lg.dom, hsv)
        fun shade(v: Float, sat: Float = hsv[1]): Int = Color.HSVToColor(floatArrayOf(hsv[0], sat.coerceIn(0f, 1f), v))
        c.drawColor(shade(0.08f, hsv[1] * 0.8f))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val sk = hf * 0.62f
        fun stripe(x1: Float, x2: Float) {
            val path = Path()
            path.moveTo(x1, 0f); path.lineTo(x2, 0f); path.lineTo(x2 + sk, hf); path.lineTo(x1 + sk, hf); path.close()
            c.drawPath(path, p)
        }
        p.shader = LinearGradient(0f, 0f, 0f, hf, shade(0.95f), shade(0.55f), Shader.TileMode.CLAMP)
        stripe(-0.16f * wf, 0.10f * wf)
        stripe(0.60f * wf, 0.86f * wf)
        p.shader = LinearGradient(0f, 0f, 0f, hf, shade(0.7f), shade(0.3f), Shader.TileMode.CLAMP)
        stripe(0.30f * wf, 0.34f * wf)
        val bw = lg.bmp.width; val bh = lg.bmp.height
        val sc = minOf(wf * 0.5f / bw, hf * 0.46f / bh)
        val dw = (bw * sc).toInt().coerceAtLeast(1); val dh = (bh * sc).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(lg.bmp, dw, dh, true)
        val lx = (wf - dw) / 2f; val ly = (hf - dh) / 2f
        val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (lg.clean) c.drawBitmap(scaled, lx, ly, lp)
        else { // ícone sem fundo removível: vira um quadrado arredondado
            val path = Path()
            path.addRoundRect(RectF(lx, ly, lx + dw, ly + dh), dw * 0.2f, dw * 0.2f, Path.Direction.CW)
            c.save(); c.clipPath(path); c.drawBitmap(scaled, lx, ly, lp); c.restore()
        }
        return Big(BitmapDrawable(resources, out), null)
    }

    // Card: usa a imagem que você escolheu para esse app; se não houver, gera o banner automático
    private fun buildCard(a: App): Big {
        val f = File(filesDir, "banner_${a.pkg}.jpg")
        if (f.exists()) {
            val bmp = decodeScaled(1280) { BitmapFactory.decodeFile(f.path, it) }
            if (bmp != null) return Big(BitmapDrawable(resources, bmp), null)
        }
        return makeBanner(bigLogo(a))
    }

    private fun storeBanner(pkg: String, load: () -> Bitmap?) {
        io.execute {
            val bmp = try { load() } catch (t: Throwable) { null }
            var ok = false
            if (bmp != null) try {
                FileOutputStream(File(filesDir, "banner_$pkg.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                ok = true
            } catch (t: Throwable) {}
            ui.post {
                if (isDestroyed) return@post
                if (ok) { bigCache.remove(pkg); showFeatured() }
                else Toast.makeText(ctx, "Não foi possível usar essa imagem", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun pickBanner(pkg: String) {
        prefs.edit().putString("banner_pending", pkg).apply()
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 43)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Nenhum app de arquivos encontrado. Use a opção da pasta do launcher.", Toast.LENGTH_LONG).show()
        }
    }

    private fun bannerFromFolder(pkg: String) {
        val dir = getExternalFilesDir(null)
        val f = if (dir == null) null else listOf("card.jpg", "card.png", "card.jpeg").map { File(dir, it) }.firstOrNull { it.exists() }
        if (f == null) {
            Toast.makeText(ctx, "Coloque card.jpg em ${dir?.absolutePath}", Toast.LENGTH_LONG).show()
            return
        }
        storeBanner(pkg) { decodeScaled(1280) { BitmapFactory.decodeFile(f.path, it) } }
    }

    // ---------------------------------------------------------------- otimizador (precisa de root)
    private class Sh(val code: Int, val out: String)
    private class SysApp(val pkg: String, val label: String, var enabled: Boolean)

    private fun su(cmd: String): Sh? = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "( $cmd ) 2>&1"))
        val out = p.inputStream.bufferedReader().readText()
        Sh(p.waitFor(), out)
    } catch (e: Throwable) { null }

    private fun readSys(path: String): String? = try { File(path).readText().trim() } catch (e: Throwable) { null }

    private fun cpuTempC(): Int? {
        for (z in 0..3) {
            val v = readSys("/sys/class/thermal/thermal_zone$z/temp")?.toIntOrNull() ?: continue
            return if (v > 1000) v / 1000 else v
        }
        return null
    }

    private fun availMb(): Long {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    private fun statusLine(): String {
        val parts = ArrayList<String>()
        cpuTempC()?.let { parts.add("CPU $it°C") }
        readSys("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")?.toLongOrNull()?.let { parts.add("${it / 1000} MHz") }
        parts.add("RAM livre ${availMb()} MB")
        return parts.joinToString(" · ")
    }

    // Proteção: se a CPU passar de 85 °C com o modo desempenho ligado, ele desliga sozinho
    private val thermalTick = object : Runnable {
        override fun run() {
            if (!prefs.getBoolean("perf_on", false)) return
            val t = cpuTempC()
            if (t != null && t >= 85) setPerf(false, note = "Modo desempenho desligado: CPU a $t °C")
            else ui.postDelayed(this, 20000)
        }
    }

    // Modo desempenho: CPU sempre na frequência máxima de fábrica (não passa do limite do chip)
    private fun setPerf(on: Boolean, quiet: Boolean = false, note: String? = null) {
        ui.removeCallbacks(thermalTick)
        sh.execute {
            val base = "/sys/devices/system/cpu/cpu0/cpufreq"
            var ok = false
            if (on) {
                val cur = su("cat $base/scaling_governor")?.out?.trim() ?: ""
                if (cur.isNotEmpty() && cur != "performance" && !cur.contains(" ") && prefs.getString("gov_orig", null) == null)
                    prefs.edit().putString("gov_orig", cur).apply()
                su("for c in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do if grep -q performance \$c/scaling_available_governors 2>/dev/null; then echo performance > \$c/scaling_governor; else cat \$c/scaling_max_freq > \$c/scaling_min_freq; fi; done")
                val chk = su("cat $base/scaling_governor; cat $base/scaling_min_freq; cat $base/scaling_max_freq")?.out?.trim()?.lines() ?: emptyList()
                ok = chk.size >= 3 && (chk[0] == "performance" || chk[1] == chk[2])
            } else {
                var orig = prefs.getString("gov_orig", null)
                if (orig == null) orig = su("cat $base/scaling_available_governors")?.out?.trim()?.split(" ")?.firstOrNull { it.isNotEmpty() && it != "performance" }
                if (orig == null) orig = "interactive"
                su("for c in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do cat \$c/cpuinfo_min_freq > \$c/scaling_min_freq; echo $orig > \$c/scaling_governor; done")
                ok = true
            }
            ui.post {
                if (isDestroyed) return@post
                if (ok) { prefs.edit().putBoolean("perf_on", on).apply(); if (on) ui.postDelayed(thermalTick, 20000) }
                else prefs.edit().putBoolean("perf_on", false).apply()
                if (!quiet) Toast.makeText(ctx,
                    note ?: if (ok) (if (on) "Modo desempenho ligado" else "Modo desempenho desligado") else "Não consegui: root negado ou o kernel não permite",
                    Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun cleanMemory() {
        val before = availMb()
        Toast.makeText(ctx, "Limpando memória...", Toast.LENGTH_SHORT).show()
        sh.execute {
            su("sync; echo 3 > /proc/sys/vm/drop_caches; am kill-all")
            try { Thread.sleep(1200) } catch (e: Exception) {}
            ui.post { if (!isDestroyed) Toast.makeText(ctx, "Memória livre: $before MB → ${availMb()} MB", Toast.LENGTH_LONG).show() }
        }
    }

    private fun showOptimizerMenu() {
        val perf = prefs.getBoolean("perf_on", false)
        showMenu("Otimizador", listOf(
            MenuItem(statusLine(), keep = true) { popLayer(); showOptimizerMenu() },
            MenuItem(if (perf) "Modo desempenho: ligado" else "Modo desempenho: desligado", keep = true) { popLayer(); setPerf(!perf) },
            MenuItem("Limpar memória agora") { cleanMemory() },
            MenuItem("Apps do sistema  ›") { showSystemApps() }
        ))
    }

    private val protectedPrefixes = listOf(
        "android.", "com.android.settings", "com.android.systemui", "com.android.providers", "com.android.inputmethod",
        "com.android.packageinstaller", "com.android.shell", "com.android.bluetooth", "com.android.phone", "com.android.server",
        "com.android.externalstorage", "com.android.documentsui", "com.android.certinstaller", "com.android.keychain",
        "com.android.location", "com.android.mtp", "com.android.nfc", "com.android.tv", "com.android.webview", "com.android.vending",
        "com.android.defcontainer", "com.android.inputdevices", "com.google.android.gms", "com.google.android.gsf",
        "com.google.android.webview", "com.google.android.packageinstaller", "com.google.android.permissioncontroller",
        "com.google.android.inputmethod", "com.google.android.tv", "com.droidlogic", "com.amlogic", "com.softwinner",
        "com.rockchip", "com.mediatek", "com.allwinner", "com.hisilicon")

    private fun isProtectedPkg(p: String) = p == packageName || p == "android" || protectedPrefixes.any { p.startsWith(it) }

    private fun showSystemApps() {
        Toast.makeText(ctx, "Carregando apps do sistema...", Toast.LENGTH_SHORT).show()
        io.execute {
            val pm = packageManager
            val list = try {
                pm.getInstalledApplications(0)
                    .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && !isProtectedPkg(it.packageName) }
                    .map { SysApp(it.packageName, it.loadLabel(pm).toString(), it.enabled) }
                    .sortedBy { it.label.lowercase() }
            } catch (t: Throwable) { emptyList<SysApp>() }
            ui.post { if (!isDestroyed) buildSysPanel(list) }
        }
    }

    private inner class SysAdapter(val data: List<SysApp>) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(p: Int) = data[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup): View {
            val row = (v as? LinearLayout) ?: LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(10), dp(16), dp(10))
                addView(TextView(ctx).apply {
                    setTextColor(Color.WHITE); px(15f); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(TextView(ctx).apply { px(13f); setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(WRAP, WRAP))
            }
            val a = data[p]
            (row.getChildAt(0) as TextView).text = a.label + "   " + a.pkg
            val st = row.getChildAt(1) as TextView
            st.text = if (a.enabled) "ATIVO" else "DESATIVADO"
            st.setTextColor(if (a.enabled) GREEN else Color.parseColor("#FF5555"))
            return row
        }
    }

    private fun buildSysPanel(list: List<SysApp>) {
        val panel = FrameLayout(ctx).apply { setBackgroundColor(Color.parseColor("#F2030803")); isClickable = true }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(24), dp(48), dp(16)) }
        col.addView(TextView(ctx).apply { text = "Apps do sistema"; px(22f); setTypeface(null, Typeface.BOLD); setTextColor(GREEN) })
        col.addView(TextView(ctx).apply {
            text = "Toque para desativar ou ativar. Dá para desfazer. Apps essenciais não aparecem aqui."
            px(13f); setTextColor(Color.parseColor("#D0E8D0")); setPadding(0, dp(4), 0, dp(10))
        })
        val undo = TextView(ctx).apply {
            text = "Reativar tudo que eu desativei"; px(15f); setTextColor(Color.WHITE)
            setPadding(dp(16), dp(10), dp(16), dp(10)); isFocusable = true; background = box()
        }
        focusAnim(undo, 1.03f)
        col.addView(undo, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        val ad = SysAdapter(list)
        val lv = ListView(ctx).apply {
            divider = null; isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            selector = GradientDrawable().apply {
                setColor(Color.parseColor("#33000000")); cornerRadius = dp(10).toFloat(); setStroke(dp(3), GREEN)
            }
            adapter = ad
            setOnItemClickListener { _, _, p, _ -> toggleSys(list[p]) { ad.notifyDataSetChanged() } }
        }
        undo.setOnClickListener { reenableAll(list) { ad.notifyDataSetChanged() } }
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        panel.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        pushLayer(panel, if (list.isEmpty()) undo else lv, null)
    }

    private fun toggleSys(a: SysApp, done: () -> Unit) {
        val target = !a.enabled
        Toast.makeText(ctx, (if (target) "Ativando " else "Desativando ") + a.label + "...", Toast.LENGTH_SHORT).show()
        sh.execute {
            su(if (target) "pm enable ${a.pkg}" else "pm disable-user --user 0 ${a.pkg}")
            val now = try { packageManager.getApplicationInfo(a.pkg, 0).enabled } catch (e: Throwable) { target }
            ui.post {
                if (isDestroyed) return@post
                if (now == target) {
                    a.enabled = target
                    val set = HashSet(prefs.getStringSet("debloat_set", emptySet()) ?: emptySet<String>())
                    if (target) set.remove(a.pkg) else set.add(a.pkg)
                    prefs.edit().putStringSet("debloat_set", set).apply()
                    done()
                } else Toast.makeText(ctx, "Não foi possível: precisa de root ou o sistema recusou", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun reenableAll(list: List<SysApp>, done: () -> Unit) {
        val set = HashSet(prefs.getStringSet("debloat_set", emptySet()) ?: emptySet<String>())
        if (set.isEmpty()) { Toast.makeText(ctx, "Nada para reativar", Toast.LENGTH_SHORT).show(); return }
        sh.execute {
            su(set.joinToString("; ") { "pm enable $it" })
            ui.post {
                if (isDestroyed) return@post
                prefs.edit().remove("debloat_set").apply()
                for (a in list) if (set.contains(a.pkg)) a.enabled = true
                done()
                Toast.makeText(ctx, "Apps reativados", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------- barra de status (temperatura, RAM, rede, gamepad)
    private var lastNetRes = 0

    private val statusTick = object : Runnable {
        override fun run() {
            updateStatus()
            if (resumed && prefs.getBoolean("status_on", true)) ui.postDelayed(this, 5000)
        }
    }

    @Suppress("DEPRECATION")
    private fun updateStatus() {
        if (!prefs.getBoolean("status_on", true)) return
        val t = cpuTempC()
        sysText.text = (if (t != null) "CPU $t°C\n" else "") + "RAM ${availMb()} MB"
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ni = try { cm.activeNetworkInfo } catch (e: Exception) { null }
        val up = ni != null && ni.isConnected
        val res = if (ni != null && ni.isConnected && ni.type == ConnectivityManager.TYPE_ETHERNET) R.drawable.ic_ethernet else R.drawable.ic_wifi
        if (res != lastNetRes) { lastNetRes = res; icNet.setImageResource(res) }
        icNet.alpha = if (up) 1f else 0.3f
        var pad = false
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            val src = d.sources
            if (!d.isVirtual && ((src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                        (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK)) { pad = true; break }
        }
        icPad.visibility = if (pad) View.VISIBLE else View.GONE
    }

    private fun applyStatusVisibility() {
        val on = prefs.getBoolean("status_on", true)
        statusBox.visibility = if (on) View.VISIBLE else View.GONE
        ui.removeCallbacks(statusTick)
        if (on && resumed) ui.post(statusTick)
    }

    // ---------------------------------------------------------------- protetor de tela com relógio
    private lateinit var saver: FrameLayout
    private lateinit var saverBox: LinearLayout
    private var saverOn = false
    private var saverMin = 10
    private var lastIdle = 0L
    private val idleRun = Runnable { showSaver() }
    private val saverMove = object : Runnable {
        override fun run() {
            if (!saverOn) return
            val dx = (Math.random() - 0.5) * root.width * 0.5
            val dy = (Math.random() - 0.5) * root.height * 0.5
            fx(saverBox, 3000, tx = dx.toFloat(), ty = dy.toFloat()) // o relógio passeia devagar
            ui.postDelayed(this, 20000)
        }
    }

    private fun buildSaver() {
        saver = FrameLayout(ctx).apply {
            setBackgroundColor(Color.BLACK); visibility = View.GONE; isClickable = true; setOnClickListener { hideSaver() }
        }
        saverBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        saverBox.addView(TextClock(ctx).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"; px(96f)
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(accentTint(0.6f, 0.75f))
        })
        saverBox.addView(TextClock(ctx).apply {
            format12Hour = "EEEE, dd MMM yyyy"; format24Hour = "EEEE, dd MMM yyyy"; px(20f)
            setTextColor(Color.parseColor("#9AA89A"))
        })
        saver.addView(saverBox, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(saver, MATCH, MATCH)
    }

    private fun showSaver() {
        if (saverMin <= 0 || !resumed || saverOn) return
        saverOn = true
        saverBox.translationX = 0f; saverBox.translationY = 0f
        saver.alpha = 0f; saver.visibility = View.VISIBLE; saver.bringToFront()
        fx(saver, 700, alpha = 1f)
        updateAmbient()
        ui.postDelayed(saverMove, 6000)
    }

    private fun hideSaver() {
        if (!saverOn) return
        saverOn = false
        ui.removeCallbacks(saverMove); fxStop(saver); fxStop(saverBox)
        saver.visibility = View.GONE
        updateAmbient(); resetIdle(true)
    }

    private fun resetIdle(force: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastIdle < 1000) return
        lastIdle = now
        ui.removeCallbacks(idleRun)
        if (saverMin > 0 && resumed && !saverOn) ui.postDelayed(idleRun, saverMin * 60_000L)
    }

    private fun userActivity() {
        if (autoPending) { autoPending = false; ui.removeCallbacks(autoRun) } // qualquer tecla cancela o app inicial
        resetIdle()
    }

    override fun onUserInteraction() { super.onUserInteraction(); userActivity() }

    // Analógico com folga não conta como atividade; mouse e mover o analógico de verdade contam
    private fun isRealMotion(ev: MotionEvent): Boolean {
        if ((ev.source and InputDevice.SOURCE_CLASS_JOYSTICK) != 0)
            return Math.abs(ev.getAxisValue(MotionEvent.AXIS_X)) > 0.5f || Math.abs(ev.getAxisValue(MotionEvent.AXIS_Y)) > 0.5f ||
                    Math.abs(ev.getAxisValue(MotionEvent.AXIS_HAT_X)) > 0.5f || Math.abs(ev.getAxisValue(MotionEvent.AXIS_HAT_Y)) > 0.5f
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (isRealMotion(ev)) {
            if (saverOn) { hideSaver(); return true }
            userActivity()
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    // ---------------------------------------------------------------- abrir um app ao ligar a box
    private var autoPending = false
    private val autoRun = Runnable {
        if (autoPending) { autoPending = false; appFor("autostart")?.let { launch(it) } }
    }
    private val elapsedSave = object : Runnable {
        override fun run() { saveElapsed(); ui.postDelayed(this, 120000) }
    }

    private fun saveElapsed() { prefs.edit().putLong("last_elapsed", SystemClock.elapsedRealtime()).apply() }

    // Só dispara depois de um reinício de verdade da box, não quando o launcher apenas reabre
    private fun checkAutostart() {
        var rebooted = false
        val bc = try { Settings.Global.getInt(contentResolver, "boot_count") } catch (e: Exception) { -1 }
        if (bc >= 0) {
            val last = prefs.getInt("last_boot_count", -1)
            prefs.edit().putInt("last_boot_count", bc).apply()
            rebooted = last >= 0 && bc != last
        } else {
            val last = prefs.getLong("last_elapsed", -1L)
            rebooted = last >= 0 && SystemClock.elapsedRealtime() < last
        }
        saveElapsed()
        ui.postDelayed(elapsedSave, 120000)
        if (rebooted && !pkgFor("autostart").isNullOrEmpty()) {
            autoPending = true
            Toast.makeText(ctx, "Abrindo o app inicial... aperte qualquer botão para cancelar", Toast.LENGTH_LONG).show()
            ui.postDelayed(autoRun, 7000)
        }
    }

    // ---------------------------------------------------------------- menu de energia (precisa de root)
    private fun showPowerMenu() {
        showMenu("Energia", listOf(
            MenuItem("Cancelar") { },
            MenuItem("Reiniciar a box") { powerCmd("svc power reboot || reboot", "Reiniciando...") },
            MenuItem("Desligar a box") { powerCmd("svc power shutdown || reboot -p", "Desligando...") }
        ))
    }

    private fun powerCmd(cmd: String, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
        sh.execute {
            val r = su(cmd)
            if (r == null || r.code != 0)
                ui.post { if (!isDestroyed) Toast.makeText(ctx, "Não consegui: precisa de root", Toast.LENGTH_LONG).show() }
        }
    }

    // ---------------------------------------------------------------- lista manual de jogos
    private fun gameSet(k: String): Set<String> = HashSet(prefs.getStringSet(k, emptySet()) ?: emptySet<String>())

    private fun isGameApp(a: App) =
        (a.isGame || gameSet("games_add").contains(a.pkg)) && !gameSet("games_remove").contains(a.pkg)

    private fun toggleGame(a: App) {
        val add = gameSet("games_add").toMutableSet()
        val rem = gameSet("games_remove").toMutableSet()
        if (isGameApp(a)) { add.remove(a.pkg); rem.add(a.pkg) } else { rem.remove(a.pkg); add.add(a.pkg) }
        prefs.edit().putStringSet("games_add", add).putStringSet("games_remove", rem).apply()
    }

    // ---------------------------------------------------------------- clima (Open-Meteo, sem chave)
    private fun startWeather() {
        showWeather(prefs.getInt("w_temp", Int.MIN_VALUE), prefs.getInt("w_code", -1))
        val age = System.currentTimeMillis() - prefs.getLong("w_time", 0L)
        if (age > WEATHER_MS) fetchWeather()
        else { ui.removeCallbacks(weatherTick); ui.postDelayed(weatherTick, WEATHER_MS - age) }
    }

    private fun fetchWeather() {
        if (!prefs.getBoolean("weather_on", true) || weatherBusy) return
        weatherBusy = true
        ui.removeCallbacks(weatherTick)
        net.execute {
            var ok = false
            try {
                val now = System.currentTimeMillis()
                var lat = prefs.getFloat("w_lat", 999f)
                var lon = prefs.getFloat("w_lon", 999f)
                if (lat == 999f || now - prefs.getLong("w_loc_time", 0L) > 7L * 24 * 3600 * 1000) {
                    // localização aproximada pelo IP da sua internet
                    val j = JSONObject(httpGet("https://get.geojs.io/v1/ip/geo.json"))
                    lat = j.getString("latitude").toFloat(); lon = j.getString("longitude").toFloat()
                    prefs.edit().putFloat("w_lat", lat).putFloat("w_lon", lon).putLong("w_loc_time", now).apply()
                }
                val w = JSONObject(httpGet("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto"))
                val cur = w.getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val code = cur.getInt("weather_code")
                prefs.edit().putInt("w_temp", t).putInt("w_code", code).putLong("w_time", System.currentTimeMillis()).apply()
                ok = true
                ui.post { if (!isDestroyed) showWeather(t, code) }
            } catch (e: Throwable) {
            } finally {
                ui.post {
                    weatherBusy = false
                    if (!isDestroyed) {
                        ui.removeCallbacks(weatherTick)
                        // se falhou (ex.: Wi-Fi ainda conectando após ligar a box), tenta de novo em 1 minuto
                        ui.postDelayed(weatherTick, if (ok) WEATHER_MS else 60_000L)
                    }
                }
            }
        }
    }

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun showWeather(temp: Int, code: Int) {
        if (temp == Int.MIN_VALUE || !prefs.getBoolean("weather_on", true)) { wBox.visibility = View.GONE; return }
        wTemp.text = "$temp°C"
        wDesc.text = when (code) {
            0 -> "Céu limpo"
            1, 2 -> "Poucas nuvens"
            3 -> "Nublado"
            45, 48 -> "Neblina"
            in 51..57 -> "Garoa"
            in 61..67 -> "Chuva"
            in 71..77, 85, 86 -> "Neve"
            in 80..82 -> "Pancadas de chuva"
            in 95..99 -> "Tempestade"
            else -> ""
        }
        wBox.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------- menus e seletor
    private fun pickFor(key: String) {
        showPicker("Escolha um aplicativo", apps, { a ->
            prefs.edit().putString(key, a.pkg).apply(); popLayer(); refreshUi()
        }, null)
    }

    private fun showApps(gamesOnly: Boolean) {
        if (!loaded) return
        showPicker(if (gamesOnly) "Jogos" else "Todos os aplicativos",
            visibleApps(gamesOnly), { launch(it) }, { appMenu(it, gamesOnly) },
            if (gamesOnly) "Nenhum jogo. Em Todos os aplicativos, segure OK num app e escolha Adicionar a Jogos" else "Nenhum aplicativo encontrado")
    }

    private fun tileMenu(key: String) {
        val a = appFor(key)
        val items = ArrayList<MenuItem>()
        items.add(MenuItem("Trocar aplicativo") { pickFor(key) })
        if (key == "featured" && a != null) {
            items.add(MenuItem("Imagem do card (do aparelho)") { pickBanner(a.pkg) })
            items.add(MenuItem("Imagem do card (pasta do launcher)") { bannerFromFolder(a.pkg) })
            if (File(filesDir, "banner_${a.pkg}.jpg").exists())
                items.add(MenuItem("Voltar ao card automático") {
                    File(filesDir, "banner_${a.pkg}.jpg").delete(); bigCache.remove(a.pkg); showFeatured()
                })
        }
        items.add(MenuItem("Remover") { prefs.edit().putString(key, "").apply(); refreshUi() })
        showMenu(a?.label ?: "", items)
    }

    private fun appMenu(a: App, gamesOnly: Boolean) {
        showMenu(a.label, listOf(
            MenuItem(if (isGameApp(a)) "Tirar de Jogos" else "Adicionar a Jogos") {
                toggleGame(a); closeAllLayers(); showApps(gamesOnly)
            },
            MenuItem("Esconder da lista") { hideApp(a, true); closeAllLayers(); showApps(gamesOnly) },
            MenuItem("Informações do app") {
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) } catch (e: Exception) {}
            },
            MenuItem("Desinstalar") {
                try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) } catch (e: Exception) {}
            }
        ))
    }

    // Menu próprio (em vez de AlertDialog) para o gamepad e o controle funcionarem igual em tudo
    private fun showMenu(title: String, items: List<MenuItem>) {
        val panel = FrameLayout(ctx).apply {
            setBackgroundColor(Color.parseColor("#B3000000")); isClickable = true; setOnClickListener { popLayer() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; isClickable = true; clipChildren = false
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F0061006")); cornerRadius = dp(14).toFloat(); setStroke(dp(2), accentTint(1f, 0.55f))
            }
        }
        col.addView(TextView(ctx).apply {
            text = title; px(18f); setTypeface(null, Typeface.BOLD); setTextColor(GREEN)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, 0, 0, dp(10))
        })
        var first: View? = null
        for (item in items) {
            val b = TextView(ctx).apply {
                text = item.label; px(16f); setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(10), dp(16), dp(10)); isFocusable = true; background = box()
                setOnClickListener { if (!item.keep) popLayer(); item.action() }
                focusAnim(this, 1.04f)
            }
            col.addView(b, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(3), 0, dp(3)) })
            if (first == null) first = b
        }
        val sv = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(col)
        }
        panel.addView(sv, FrameLayout.LayoutParams(dp(340), WRAP, Gravity.CENTER))
        pushLayer(panel, first ?: col, null)
    }

    private fun showPicker(title: String, list: List<App>, onClick: (App) -> Unit, onLong: ((App) -> Unit)?,
                           emptyText: String = "Nenhum aplicativo encontrado") {
        val openedAt = SystemClock.uptimeMillis()
        val panel = FrameLayout(ctx).apply { setBackgroundColor(Color.parseColor("#F2030803")); isClickable = true }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(24), dp(48), dp(16)); clipChildren = false
        }
        col.addView(TextView(ctx).apply {
            text = title; px(22f); setTypeface(null, Typeface.BOLD); setTextColor(GREEN); setPadding(0, 0, 0, dp(12))
        })
        val msg: TextView? = if (list.isEmpty()) TextView(ctx).apply {
            text = emptyText; px(16f); setTextColor(Color.WHITE); isFocusable = true
        } else null
        if (msg != null) col.addView(msg)

        val grid = GridView(ctx).apply {
            numColumns = 6; verticalSpacing = dp(8); horizontalSpacing = dp(8)
            clipToPadding = false; clipChildren = false
            isScrollingCacheEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            selector = GradientDrawable().apply {
                setColor(Color.parseColor("#33000000")); cornerRadius = dp(10).toFloat(); setStroke(dp(3), GREEN)
            }
            adapter = object : BaseAdapter() {
                override fun getCount() = list.size
                override fun getItem(p: Int) = list[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                    val c = (v as? LinearLayout) ?: LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                        setPadding(dp(6), dp(10), dp(6), dp(10))
                        addView(ImageView(ctx), LinearLayout.LayoutParams(dp(56), dp(56)))
                        addView(TextView(ctx).apply {
                            setTextColor(Color.WHITE); px(12f); maxLines = 1
                            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
                        }, LinearLayout.LayoutParams(MATCH, WRAP))
                    }
                    fxStop(c); c.scaleX = 1f; c.scaleY = 1f; c.alpha = 1f // item reciclado volta ao normal
                    if (SystemClock.uptimeMillis() - openedAt < 450 && p < 24) { // entrada em cascata
                        c.alpha = 0f; c.scaleX = 0.8f; c.scaleY = 0.8f
                        fx(c, 280, delay = (p % 6 + p / 6) * 40L, interp = overshoot, scale = 1f, alpha = 1f)
                    }
                    (c.getChildAt(0) as ImageView).setImageDrawable(list[p].icon)
                    (c.getChildAt(1) as TextView).text = list[p].label
                    return c
                }
            }
            var sel: View? = null
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    sel?.let { fx(it, 120, scale = 1f) }
                    sel = view
                    view?.let { fx(it, 220, interp = overshoot, scale = 1.12f) }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {
                    sel?.let { fx(it, 120, scale = 1f) }; sel = null
                }
            }
            setOnItemClickListener { _, _, p, _ -> onClick(list[p]) }
            if (onLong != null) setOnItemLongClickListener { _, _, p, _ -> onLong(list[p]); true }
        }
        col.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        panel.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val ctxAction: (() -> Unit)? = onLong?.let { f ->
            fun() { val p = grid.selectedItemPosition; if (p in list.indices) f(list[p]) }
        }
        pushLayer(panel, msg ?: grid, ctxAction)
    }
}
